import praw
import re
import mysql.connector

bot_username = ''
monitor_sr = ''

def confirm_user(user_name):
    q = "SELECT * FROM user where username = '{}'".format(user_name)
    c.execute(q)
    res = c.fetchone()
    if res is None:
        q = "INSERT INTO user VALUES ('{}', 0, 0, 0)".format(user_name)
        c.execute(q)
        db.commit()

db = mysql.connector.connect(host = 'localhost', user = 'root', password = '', database = 'loanbot')
c = db.cursor()

r = praw.Reddit(username = bot_username,
                password = '',
                client_id = '',
                client_secret = '',
                user_agent = 'Customized Loan Bot')

subreddit = r.subreddit(monitor_sr)

for comment in subreddit.stream.comments(skip_existing = True):
    try:
        if str(comment.body).startswith('$ ') and str(comment.author) != bot_username:
            msg_content = comment.body
            msg_raw = msg_content.split()
            cmd = msg_raw[1]
            if cmd == 'check':
                confirm_user(str(comment.author))
                print('check command')
                try:
                    user_to_check = msg_raw[2]
                    user_to_check = re.sub('u/', '', user_to_check)

                    q = "SELECT * FROM user WHERE username = '{}'".format(user_to_check)
                    c.execute(q)
                    res = c.fetchone()
                    if res is not None:
                        table_txt="USERNAME | BORROWED LOANS | LENT LOANS | REPAID LOANS\n:- | :-: | :-: | -:\n{} | {} | {} | {}".format(
                            res[0], res[1], res[2], res[3]
                        )
                        comment.reply(table_txt)
                    
                    else:
                        table_txt="USERNAME | BORROWED LOANS | LENT LOANS | REPAID LOANS\n:- | :-: | :-: | -:\n |  |  | "
                        comment.reply(table_txt)
                except IndexError:
                    comment.reply('`Invalid format. Please use: $ check [u/username]`')
            
            elif cmd == 'loan':
                confirm_user(str(comment.author))
                print('loan command')
                try:
                    lender = str(comment.author)
                    borrower = msg_raw[2]
                    borrower = re.sub('u/', '', borrower)
                    amount = msg_raw[3]
                    cr_code = msg_raw[4]
                    
                    q = "INSERT INTO ongoing_loans VALUES ('{}', '{}', {}, '{}', 'un')".format(borrower, lender, amount, cr_code)
                    c.execute(q)
                    db.commit()

                    comment.reply('`UPDATE:` ' + lender + ' has given ' + amount + ' ' + cr_code + ' to ' + borrower)
                except IndexError:
                    comment.reply('`Invalid format. Please use: $ loan [u/borrower] [amount] [currency code]`')
            
            elif cmd == 'paid':
                confirm_user(str(comment.author))
                print('paid command')
                try:
                    lender = str(comment.author)
                    borrower = msg_raw[2]
                    borrower = re.sub('u/', '', borrower)
                    amount = msg_raw[3]
                    cr_code = msg_raw[4]

                    q = "UPDATE user SET repaid_loans = repaid_loans + 1 WHERE username = '{}'".format(borrower)
                    c.execute(q)
                    db.commit()

                    comment.reply('`UPDATE:` ' + borrower + ' has repaid ' + lender + ' ' + amount + ' ' + cr_code)
                except IndexError:
                    comment.reply('`Invalid format. Please use: $ paid [u/borrower] [amount] [currency code]`')
            
            elif cmd == 'confirm':
                confirm_user(str(comment.author))
                print('confirm command')
                try:
                    borrower = str(comment.author)
                    lender = msg_raw[2]
                    lender = re.sub('u/', '', lender)

                    q = "SELECT amount, code FROM ongoing_loans WHERE borrower = '{}' AND lender = '{}' AND status = 'un'".format(borrower, lender)
                    c.execute(q)
                    res = c.fetchone()
                    if res is not None:
                        amount_conf = str(res[0])
                        code_conf = res[1]

                        q="UPDATE ongoing_loans SET status = 'cn' WHERE borrower = '{}' AND lender = '{}'".format(borrower, lender)
                        c.execute(q)
                        db.commit()

                        q = "UPDATE user SET lt_loans = lt_loans + 1 WHERE username = '{}'".format(lender)
                        c.execute(q)
                        q2 = "UPDATE user SET b_loans = b_loans + 1 WHERE username = '{}'".format(borrower)
                        c.execute(q2)
                        db.commit()

                        comment.reply('`UPDATE:` ' + borrower + ' confirms that ' + lender + ' has lent him ' + amount_conf + ' ' + code_conf)
                    
                    else:
                        comment.reply('`UPDATE:` ' + borrower + ' has no unconfirmed loan with ' + lender)
                except IndexError:
                    comment.reply('`Invalid format. Please use: $ confirm [u/lender]`')
            
            elif cmd == 'help':
                #confirm_user(str(comment.author))
                print('help command')
                help_txt ='''
Command Usage:
`u/iloanbot [command]`

[command]:
- `check [u/username]` : get the details of the user identified by username
- `loan [u/borrower] [amount] [currency code]` : the creator of this comment says that he has lent a loan amount to borrower
- `confirm [u/lender]` : the creator of this comment confirms that lender has lent him a loan
- `paid [u/borrower] [amount] [currency code]` : the creator of this comment confirms that the borrower has paid his loan amount
'''
                comment.reply(help_txt)
            
            else:
                comment.reply('`Please use a valid command`')

            comment.mark_read()
    
    except praw.exceptions.APIException as e:
        print(e)
